from flask import Flask,render_template,request,redirect,url_for,flash,session
from dbhelper import *

app = Flask(__name__)
app.config['SECRET_KEY'] = '!@#$%^&'


@app.route("/logout")
def logout()->None:
	#session.pop('email')
	flash("You are logged out !!!!")
	return redirect(url_for("login"))

@app.route("/home")
def home()->None:

	head:list = ['idno','lastname','firstname','course','level','action']
	if "email" in session:
		rows:list = getall('student')
		return render_template("home.html",title="home",studentlist=rows,header=head)
	else:
		flash("Login Properly !!!!")
		return redirect(url_for("login"))
		
@app.route("/login",methods=['GET','POST'])
def login()->None:
	if request.method == "POST":
		email:str = request.form['email']
		pword:str = request.form['password']
		user:list = userlogin('users',email=email,password=pword)
		if len(user)>0:
			session['email'] = email
			return redirect(url_for("home"))
		else:
			flash("Invalid User !!")
			return redirect(url_for("login"))
	else:	
		return render_template("login.html",title="user login")

		
@app.route("/")
def main ()->None:
	return "Hello Seri, Mary May"
	
if __name__== "__main__":
	app.run(debug=True)