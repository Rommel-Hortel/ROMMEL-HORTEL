from flask import Flask,render_template,request,redirect,url_for,flash,session
from dbhelper import *

uploadfolder = "static/img"
app = Flask(__name__)
app.config['SECRET_KEY'] = "!@#$%^^"
app.config["UPLOAD_FOLDER"] = uploadfolder 


@app.route("/register")
def register()->None:
	return render_template("register.html",title="register")


@app.route("/upload",methods=['POST','GET'])
def upload()->None: 
	file = request.files['webcam']
	iname = request.args.get('imagename')
	email = request.args.get('email')
	password = request.args.get('password')
	imagename = uploadfolder+"/"+iname+".jpg"
	file.save(imagename)
	ok:bool = addrecord('users',name=iname,email=email,password=password,image=imagename)
	return redirect(url_for("register"))
	
	

@app.route("/savestudent",methods=['POST'])
def savestudent()->None:
	if "email" in session:
		ok:bool = False
		idno:str = request.form['idno']
		lastname:str = request.form['lastname']
		firstname:str = request.form['firstname']
		course:str = request.form['course']
		level:str = request.form['level']
		#
		flag:str = request.form['flag']
		#
		if flag == "false":
			ok = addrecord('student',idno=idno,lastname=lastname,firstname=firstname,course=course,level=level)
			flash("New Student Added")
		else:
			ok = updaterecord('student',idno=idno,lastname=lastname,firstname=firstname,course=course,level=level)
			flash("New Student Added")
		return redirect(url_for("home"))


@app.route("/deletestudent/<idno>")
def deletestudent(idno)->None:
	ok:bool = deleterecord('student',idno=idno)
	if ok:
		flash("Record Deleted")
	return redirect(url_for("home"))


@app.route("/logout")
def logout()->None:
	session.pop('email')
	return redirect(url_for('login'))


@app.route("/home")
def home()->None:
	
	head:list = ['idno','lastname','firstname','course','level','action']	
	courses:list = [
		{
			'courseid':'---',
			'coursename':'---'
		},
		{
			'courseid':'bsit',
			'coursename':'information technology'
		},
		{
			'courseid':'bscs',
			'coursename':'computer science'
		},
		{
			'courseid':'bsis',
			'coursename':'information systems'
		},
		{
			'courseid':'bsim',
			'coursename':'information management'
		},
	]
	if "email" in session:
		rows:list = getall('student')
		for row in rows:
			print(dict(row))
		return render_template("home.html",data = rows,title="student list",head=head,courselist=courses)
	else:
		flash("Login Properly")
		return redirect(url_for("login"))

@app.route("/login",methods=['GET','POST'])
def login()->None:
	if request.method == "POST":
		email:str = request.form['email']
		password:str = request.form['password']
		user:list = userlogin('users',email=email,password=password)
		if len(user)>0:
			session['email'] = email
			return redirect(url_for("home"))
		else:
			flash("Invalid User")
			return render_template("login.html",title="user login")
	else:
		return render_template("login.html",title="user login")
	
	
	
@app.route("/")
def main()->None:
	return "Hello Flask"
	
if __name__=="__main__":
	app.run(debug=True)