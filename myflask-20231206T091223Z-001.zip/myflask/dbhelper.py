import sqlite3

database:str = "studentdb.db"

def connect():
	return sqlite3.connect(database)

def getprocess(sql)->list:
	conn = connect()
	conn.row_factory = sqlite3.Row #return dictionary type formatted rows
	cursor = conn.cursor()
	cursor.execute(sql)
	rows = cursor.fetchall()
	cursor.close()
	return rows
	
def doprocess(sql:str)->bool:	
	conn = connect()
	cursor = conn.cursor()
	cursor.execute(sql)
	conn.commit()
	cursor.close()
	return True if cursor.rowcount>0 else False

	
def deleterecord(table:str,**kwargs)->bool:
	keys:list = list(kwargs.keys())
	vals:list = list(kwargs.values())
	sql:str = f"DELETE FROM `{table}` WHERE `{keys[0]}`='{vals[0]}'"
	return doprocess(sql)
	
	
def addrecord(table:str,**kwargs)->bool:	
	keys:list = list(kwargs.keys())
	vals:list = list(kwargs.values())
	flds:str = "`,`".join(keys)
	data:str = "','".join(vals)
	sql:str = f"INSERT INTO `{table}`(`{flds}`) VALUES('{data}')"
	return doprocess(sql)

def updaterecord(table:str,**kwargs)->bool:	
	keys:list = list(kwargs.keys())
	vals:list = list(kwargs.values())
	flds:list = []
	for i in range(1,len(keys)):
		flds.append(f"`{keys[i]}`='{vals[i]}'")
	fld:str = ",".join(flds)
	sql:str = f"UPDATE `{table}` SET {fld} WHERE `{keys[0]}`='{vals[0]}'"
	return doprocess(sql)
	
	
def getall(table:str)->list:
	sql:str = f"SELECT * FROM `{table}`"
	return getprocess(sql)
	
def userlogin(table:str,**kwargs)->list:
	keys:list = list(kwargs.keys())
	values:list = list(kwargs.values())	
	sql = f"SELECT * FROM `{table}` WHERE `{keys[0]}`='{values[0]}' AND `{keys[1]}`='{values[1]}'"
	return getprocess(sql)

def main()->None:
	user:list = userlogin('users',email='echo@gmail.com',password='echo123')
	
if __name__ =="__main__":
	main()

	